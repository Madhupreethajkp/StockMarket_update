
/*
 * package com.example.springmvc;
 * 
 * //import org.junit.jupiter.api.Test; import org.junit.runner.RunWith;
 * 
 * import org.springframework.*;
 * 
 * import org.junit.Test; //import org.junit.runner.RunWith;
 * 
 * // import org.springframework.boot.test.context.SpringBootTest;
 * 
 * @RunWith(SpringRunner.class)
 * 
 * @SpringBootTest public class SpringMvcExampleApplicationTests {
 * 
 * @Test public void contextLoads() { }
 * 
 * }
 * 
 */