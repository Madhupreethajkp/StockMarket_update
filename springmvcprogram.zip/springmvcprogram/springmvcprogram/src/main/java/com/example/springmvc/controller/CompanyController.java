package com.example.springmvc.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;

import com.example.springmvc.model.Company;

public interface CompanyController {
	public String form(Company company,ModelMap model);
	 public String insertCompany(Company company) throws SQLException;
	 //   public Company updateCompany(Company company);
		public ModelAndView getCompanyList() throws Exception;
		Company updateCompany(Company company, HttpServletRequest request);
		String compareCompany();

}
